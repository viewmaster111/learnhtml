WARNING!
============================

Files in this folder are generated automatically from the xquery.js project (https://github.com/wcandillon/xquery.js).
Instructions on how to generate the XQuery parser are available at https://github.com/wcandillon/xquery.js

